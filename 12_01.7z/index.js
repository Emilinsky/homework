var a=parseFloat(aCipars.value);
var b=parseFloat(document.getElementById("bCipars").value);
var rez=parseFloat(document.getElementById("result").textContent);



function plus(a,b){
    return a+b;
	rez=parseFloat(aCipars.value)+parseFloat(bCipars.value);
    if (typeof a == number && typeof b==number){
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function minus(a,b){
	return a-b;
    if (typeof a == number && typeof b==number){
	rez=a-b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function reiz(a,b){
	return a*b;
    if (typeof a == number && typeof b==number){
	rez=a*b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function dalit(a,b){
	return a/b;
    if (typeof a == number && typeof b==number){
	rez=a/b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

