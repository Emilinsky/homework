var a,b,rez;
rez=document.getElementById(result)

function generate(aCipars){
	a=document.getElementById(aCipars);
}

function generate(bCipars){
	b=document.getElementById(bCipars);
}



function plus(a,b){
	return a+b;
    if (typeof a == number && typeof b==number){
	rez.value=a+b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function minus(a,b){
	return a-b;
    if (typeof a == number && typeof b==number){
	rez.value=a-b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function reiz(a,b){
	return a*b;
    if (typeof a == number && typeof b==number){
	rez.value=a*b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

function dalit(a,b){
	return a/b;
    if (typeof a == number && typeof b==number){
	rez.value=a/b;
	}else{
	alert('Abas vai viena no Ievadītajām vērtībām nav nummurs')
	}
}

