// //LEVEL 1
// let numbers = [4,5,6,10,14,3,2,5,6,7,99];
// var tmp, i, j;
//LEVEL 2
// let numbers = [];
// for(i=0;i<=999;i++){
//     numbers[i]=Math.round(Math.random()*1000);
// }


// for(i=0;i<=999;i++){
//     numbers[i]=Math.round(Math.random()*1000);
// }

// console.log(numbers);






// //augosa seciba
// for (i=0; i<=numbers.length; i++){
//     tmp=0;
//         for(j=0; j<=numbers.length; j++){
//             if(numbers[j]>=numbers[j+1]){
//                 tmp=numbers[j+1];
//                 numbers[j+1]=numbers[j];
//                 numbers[j]=tmp;
//             }
//         }
// }
// console.log('augosais masivs: '+numbers);


// //dilstosa seciba
// for (i=0; i<=numbers.length; i++){
//     tmp=0;
//         for(j=0; j<=numbers.length; j++){
//             if(numbers[j+1]>=numbers[j]){
//                 tmp=numbers[j];
//                 numbers[j]=numbers[j+1];
//                 numbers[j+1]=tmp;
//             }
//         }
// }


// console.log('dilstosais masivs: '+numbers);

//LEVEL HACKERMANS
let diogA = 0;
let diogB = 0;
let size=1000;
let tmp;
let A = [];
let B = [];
let ddM = [A,B];
for(i=0;i<=size-1;i++){
    ddM[i]=[];
}


for (i = 0; i < size; i++) {
    for (j = 0; j < size; j++) {
        ddM[i][j] = Math.round(Math.random()*1000);
    }
}

//Diognale A saskaitit
for(i=0;i<=size-1;i++){
    for(j=0;j<=size-1;j++){
        if(j==i){
        diogA=diogA+(ddM[i][j]);
    }
    }
}

//Diognale B saskaitit
tmp=1;
for(i=0;i<=size-1;i++){
    for(j=size-1;j>=0;j--){
        if(j==(size-tmp)){
        diogB=diogB+(ddM[i][j]);
        i++;
        }
        tmp=tmp+1;
    }
}
let sum=0;
sum=diogA+diogB;

        // console.table(ddM);
        console.log(diogA);
        console.log(diogB);
        console.log(sum);