var money = 0;
var modifier = 1;
var upgradeCost = 10;
let autoClickActive = false;
let autoMulti = 1;
let critMulti = 2;
let critChance = 0;
let critCookie;
let timesIncCC = 1;
let tier1cost = 500;
let tier2cost = 5000;
let critCost = 500;
let multiCost = 250;



function init() {
	updateRender();
	let cookie = document.querySelector(".cookie");
	let upgradeSelector = document.querySelector(".upgrade span");
	let critChanceINC = document.querySelector(".itemCritChance");
	let critMultiINC = document.querySelector(".itemCritMulti");	

	cookie.addEventListener("click", function () {
		click();
	});
	upgradeSelector.addEventListener("click", function () {
		upgrade();
	});
	critChanceINC.addEventListener("click", function () {
		increaseCritChance();
	});
	critMultiINC.addEventListener("click", function () {
		increaseCritMulti();
	});
    autoClickSelector.addEventListener("click", function () {
		autoClickActive = true;
        setTimeout(autoMultiClick, 1000);
	});
}

window.addEventListener("DOMContentLoaded", (event) => {
	init();
});

function updateRender() {
	let moneySelector = document.querySelector(".money-output");
	moneySelector.innerHTML = money;

	let upgradeCostSelector = document.querySelector(".upgrade-cost");
	upgradeCostSelector.innerHTML = upgradeCost;

	let upgradeCritChanceSelector = document.querySelector(".crit-chance");
	upgradeCritChanceSelector.innerHTML = Math.floor(critChance*100);
	
	let upgradeCritChanceCostSelector = document.querySelector(".crit-chance-upcost");
	upgradeCritChanceCostSelector.innerHTML = critCost;
	
    let upgradeCritMultiSelector = document.querySelector(".crit-multi");
	upgradeCritMultiSelector.innerHTML = Math.floor(critMulti*100);

	let upgradeCritMultiCostSelector = document.querySelector(".crit-multi-upcost");
	upgradeCritMultiCostSelector.innerHTML = multiCost;	
	
}

function click() {
	critCookie = Math.random();
	if (critCookie < critChance) {
		money = Math.round(money + modifier * critMulti);
	} else {
		money = Math.round(money + modifier);
	}
	updateRender();
}

function upgrade() {
	if (money >= upgradeCost) {
		if (modifier < 4) {
			modifier += 1;
		} else {
			modifier *= 1.25;
		}

		money -= upgradeCost;

		upgradeCost = Math.round(upgradeCost * 1.5);
		updateRender();
	} else {
		alert("Par maz naudas");
	}
}

function increaseCritChance(){
	if(critChance<=0.1&&money>=tier1cost*timesInc){
		critChance+=0.02;
		money=money-(tier1cost*timesInc);
		critCost=critCost+tier1cost;
		timesIncCC+=1;
	
	}
	if(timesIncCC==6){
		timesIncCC=1;
	}
	if(critCost==tier1cost*6){
		critCost=tier2cost;
	}
	if(critChance>=0.1&&critChance<=0.2&&money>=tier2cost*timesInc){
		critChance+=0.02;
		money=money-(tier2cost*timesInc);
		critCost=critCost+tier2cost;
		timesIncCC+=1;
	}
    updateRender();
}

function increaseCritMulti(){
	if(critMulti<2.55&&money>=(tier1cost/2)*timesIncCM){
		critMulti+=0.05;
		money=money-((tier1cost/2)*timesIncCM);
		multiCost=multiCost+(tier1cost/2);
		timesIncCM+=1;
	
	}
	if(timesIncCM>=11){
		timesIncCM=1;
	}
	if(multiCost>=(tier1cost/2)*11){
		multiCost=tier2cost/2;
	}
	if(critMulti>=2.5&&critMulti<=3&&money>=(tier2cost/2)*timesIncCM){
		critMulti+=0.05;
		money=money-((tier2cost/2)*timesInc);
		critCost=critCost+(tier2cost/2);
		timesIncCM+=1;
	}
    updateRender();
}

