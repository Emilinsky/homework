var $ = window.jQuery;

$(document).ready(() => {
    $('.cookie').confettiButton({
        minScale: 1500,
        maxScale: 1500,
        speed: 6,
        hoverOnly: true
    });
});
