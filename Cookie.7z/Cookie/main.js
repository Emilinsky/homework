const labelWelcome = document.querySelector('.upgradeItem');
var money = 0;
var modifier = 1;
var upgradeCost = 10;
let autoClickActive = false;
let autoMulti = 1;
let critMulti = 2;
let critChance = 0;
let critCookie;


// labelWelcome.textContent = `Increase auto-click rate by ${X}`;

function init() {
	updateRender();
	let cookie = document.querySelector(".cookie");
	let upgradeSelector = document.querySelector(".upgrade span");
    let autoClickSelector = document.querySelector(".itemAutoClick img");

	cookie.addEventListener("click", function () {
		click();
	});
	upgradeSelector.addEventListener("click", function () {
		upgrade();
	});
    autoClickSelector.addEventListener("click", function () {
		autoClickActive = true;
        setTimeout(autoMultiClick, 1000);
	});
}

window.addEventListener("DOMContentLoaded", (event) => {
	init();
});

function updateRender() {
	let moneySelector = document.querySelector(".money-output");
	moneySelector.innerHTML = money;

	let upgradeCostSelector = document.querySelector(".upgrade-cost");
	upgradeCostSelector.innerHTML = upgradeCost;

	let upgradeCritChanceSelector = document.querySelector(".crit-chance");
	upgradeCritChanceSelector.innerHTML = critChance;

    let upgradeCritMultiSelector = document.querySelector(".crit-multi");
	upgradeCritMultiSelector.innerHTML = critMulti*100;

    let upgradeAutoClickMultiSelector = document.querySelector(".crit-multi");
	upgradeAutoClickMultiSelector.innerHTML = autoMulti;
    if(autoClickActive==true){
        autoMultiClick();
    } 
}

function click() {
	critCookie = Math.random();
	if (critCookie < critChance) {
		money = Math.round(money + modifier * critMulti);
	} else {
		money = Math.round(money + modifier);
	}
	updateRender();
}

function upgrade() {
	if (money >= upgradeCost) {
		if (modifier < 4) {
			modifier += 1;
		} else {
			modifier *= 1.25;
		}

		money -= upgradeCost;

		upgradeCost = Math.round(upgradeCost * 1.5);
		updateRender();
	} else {
		alert("Par maz naudas");
	}
}

function autoMultiClick(){
    if(money>0){
    money=Math.round(money+autoMulti*(0.1*modifier));
    }
    
    updateRender();
}